# node-mysql-crud-api

Node.js + MySQL - CRUD API Example

Documentation and instructions available at https://jasonwatmore.com/post/2021/11/22/nodejs-mysql-crud-api-example-and-tutorial
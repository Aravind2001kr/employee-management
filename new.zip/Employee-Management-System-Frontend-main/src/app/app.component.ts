import {Component, OnInit} from '@angular/core';
import {Employee} from "./employee";
import {EmployeeService} from "./employee.service";
import {service} from "../app/services/service"
import {HttpErrorResponse} from "@angular/common/http";
import {NgForm} from "@angular/forms";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public employees: Employee[];
  public editEmployee: Employee;
  public deleteEmployee: Employee;
  sucess: any;

  constructor(private employeeService: EmployeeService, 
    private Service: service
    ) {
  }

  ngOnInit(): void {
    this.getEmployees();
  }


  public getEmployees(): void {
    this.employeeService.getEmployees().subscribe(
      (response: Employee[]) => {
        this.employees = response;
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    )
  }

  public addLogin(adding: NgForm): void{

  }

  // public onAddEmployee(addingForm: NgForm): void {
   
  //   this.Service.addEmployee(addingForm.value).subscribe(
  //     (response: Employee) => {
  //       console.log(response);
  //       this.getEmployees();
  //       addingForm.reset();
  //     },
  //     (error: HttpErrorResponse) => {
  //       alert(error.message);
  //     },
  //   );
  // }


  public onAddEmployee(addForm: NgForm): void {
    document.getElementById("add-employee-form").click()
    this.Service.addEmployee(addForm.value).subscribe(
      (response) => {
        console.log(response);
        if(response == "User created")
        {
          document.getElementById("login-form").click()
        }
        this.getEmployees();
        addForm.reset();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      },
    );
  }
  public onDeleteEmployee(id: number): void {
    document.getElementById("add-employee-form").click()
    this.employeeService.deleteEmployee(id).subscribe(
      (response: void) => {
        console.log(response);
        this.getEmployees();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      },
    );
  }

  public searchEmployees(key: string): void {
    const results: Employee[] = [];
    for (const employee of this.employees) {
      if (employee.name.toLowerCase().indexOf(key.toLowerCase()) !== -1
        || employee.email.toLowerCase().indexOf(key.toLowerCase()) !== -1
        || employee.position.toLowerCase().indexOf(key.toLowerCase()) !== -1
        || employee.phoneNumber.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
        results.push(employee);
      }
    }
    this.employees = results;
    if (results.length == 0 || !key) {
      this.getEmployees();
    }
  }

  public onOpenModal(employee: Employee, mode: string): void {
    const container = document.getElementById('main-container');
    const button = document.createElement('button');
    button.type = 'button';
    button.style.display = 'none';
    button.setAttribute('data-toggle', 'modal');
    button.setAttribute('data-target', '#' + mode);
    if (mode === "edit") {
      this.editEmployee = employee;
    }
    if (mode === "delete") {
      this.deleteEmployee = employee;
    }
    container.appendChild(button);
    button.click();
  }

  public onUpdateEmployee(employee: Employee): void {
    this.employeeService.updateEmployee(employee).subscribe(
      (response: Employee) => {
        console.log(response);
        this.getEmployees();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      },
    );
  }
}

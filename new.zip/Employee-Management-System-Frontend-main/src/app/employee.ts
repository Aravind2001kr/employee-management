export interface Employee {
  id: number
  name: string
  email: string
  position: string
  phoneNumber: string
  imageUrl: string
  employeeCode: string
}

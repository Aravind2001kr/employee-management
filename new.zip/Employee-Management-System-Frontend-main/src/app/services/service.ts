import { Injectable } from "@angular/core";

import { HttpClient } from "@angular/common/http";

import { environment } from "src/environments/environment";

import { Router } from "@angular/router";

@Injectable({

      providedIn: "root",
    
    })


export class service {
    private url = environment.apiBaseUrl;

    constructor(
        private http: HttpClient
    ){

    }


    addEmployee(addingForm){

        return this.http.post(this.url + "/create" , addingForm);
    }



}    